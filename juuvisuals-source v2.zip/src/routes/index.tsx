import { createFileRoute } from "@tanstack/react-router";
import homeHtml from "../home.html?raw";

export const Route = createFileRoute("/")({
  server: {
    handlers: {
      GET: () =>
        new Response(homeHtml, {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
    },
  },
  component: Index,
});

function Index() {
  return null;
}
