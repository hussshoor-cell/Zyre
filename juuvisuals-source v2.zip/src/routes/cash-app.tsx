import { createFileRoute } from "@tanstack/react-router";
import html from "../pages/cash-app.html?raw";

export const Route = createFileRoute("/cash-app")({
  server: {
    handlers: {
      GET: () =>
        new Response(html, {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
    },
  },
  component: () => null,
});
