import { createFileRoute } from "@tanstack/react-router";
import html from "../pages/fc27.html?raw";

export const Route = createFileRoute("/fc27")({
  server: {
    handlers: {
      GET: () =>
        new Response(html, {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
    },
  },
  component: () => null,
});
