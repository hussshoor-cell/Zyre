import { createFileRoute } from "@tanstack/react-router";
import html from "../pages/gift-card.html?raw";

export const Route = createFileRoute("/gift-card")({
  server: {
    handlers: {
      GET: () =>
        new Response(html, {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
    },
  },
  component: () => null,
});
