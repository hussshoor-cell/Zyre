import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/avatar")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const id = (new URL(request.url).searchParams.get("id") || "").replace(
          /\D/g,
          "",
        );
        if (!id) return new Response("Missing id", { status: 400 });

        try {
          const metaRes = await fetch(
            `https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${id}&size=150x150&format=Png&isCircular=false`,
            { headers: { accept: "application/json" } },
          );
          const meta = (await metaRes.json()) as {
            data?: Array<{ imageUrl?: string; state?: string }>;
          };
          const imageUrl = meta.data?.[0]?.imageUrl;
          if (!imageUrl) return new Response("Not found", { status: 404 });

          const img = await fetch(imageUrl);
          if (!img.ok) return new Response("Not found", { status: 404 });

          return new Response(img.body, {
            headers: {
              "content-type": img.headers.get("content-type") || "image/png",
              "cache-control": "public, max-age=3600",
            },
          });
        } catch {
          return new Response("Unable to reach Roblox", { status: 502 });
        }
      },
    },
  },
});
