import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/check-session")({
  server: {
    handlers: {
      GET: () =>
        new Response(JSON.stringify({ authenticated: true }), {
          headers: {
            "content-type": "application/json",
            "cache-control": "no-store",
          },
        }),
    },
  },
});
