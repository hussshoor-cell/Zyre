import { createFileRoute } from "@tanstack/react-router";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: {
      "content-type": "application/json",
      "cache-control": "no-store",
    },
  });

export const Route = createFileRoute("/api/search")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const q = (new URL(request.url).searchParams.get("q") || "").trim();
        if (!q) return json({ error: true, message: "Enter a Roblox username." }, 400);

        try {
          const res = await fetch("https://users.roblox.com/v1/usernames/users", {
            method: "POST",
            headers: {
              "content-type": "application/json",
              accept: "application/json",
            },
            body: JSON.stringify({ usernames: [q], excludeBannedUsers: false }),
          });

          if (!res.ok) {
            return json(
              { error: true, message: "Unable to reach Roblox right now." },
              502,
            );
          }

          const payload = (await res.json()) as {
            data?: Array<{ id: number; name: string; displayName?: string }>;
          };
          const user = payload.data?.[0];
          if (!user) {
            return json(
              { error: true, message: "That Roblox user could not be found." },
              404,
            );
          }

          return json({
            id: user.id,
            name: user.name,
            username: user.name,
            displayName: user.displayName || user.name,
            avatar: `/api/avatar?id=${user.id}`,
          });
        } catch {
          return json({ error: true, message: "Unable to reach Roblox right now." }, 502);
        }
      },
    },
  },
});
