import { createFileRoute } from "@tanstack/react-router";
import html from "../pages/cod.html?raw";

export const Route = createFileRoute("/cod")({
  server: {
    handlers: {
      GET: () =>
        new Response(html, {
          headers: { "content-type": "text/html; charset=utf-8" },
        }),
    },
  },
  component: () => null,
});
